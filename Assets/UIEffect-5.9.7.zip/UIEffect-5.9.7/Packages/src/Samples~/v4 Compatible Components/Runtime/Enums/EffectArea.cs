﻿namespace Coffee.UIEffects
{
    public enum EffectArea
    {
        RectTransform,
        Fit,
        Character
    }
}
